package modelos;

public class Cliente {
    private int idcliente;
    private String Nom_cliente;
    private String DNI_cliente;
    private String Correo_cliente;
    private String Telefono_cliente;

    public Cliente() {
    }

    public Cliente(int idcliente, String Nom_cliente, String DNI_cliente, String Correo_cliente, String Telefono_cliente) {
        this.idcliente = idcliente;
        this.Nom_cliente = Nom_cliente;
        this.DNI_cliente = DNI_cliente;
        this.Correo_cliente = Correo_cliente;
        this.Telefono_cliente = Telefono_cliente;
    }

    public Cliente(int idcliente) {
        this.idcliente = idcliente;
    }

    public Cliente(String Nom_cliente, String DNI_cliente, String Correo_cliente, String Telefono_cliente) {
        this.Nom_cliente = Nom_cliente;
        this.DNI_cliente = DNI_cliente;
        this.Correo_cliente = Correo_cliente;
        this.Telefono_cliente = Telefono_cliente;
    }

    public int getIdcliente() {
        return idcliente;
    }

    public void setIdcliente(int idcliente) {
        this.idcliente = idcliente;
    }

    public String getNom_cliente() {
        return Nom_cliente;
    }

    public void setNom_cliente(String Nom_cliente) {
        this.Nom_cliente = Nom_cliente;
    }

    public String getDNI_cliente() {
        return DNI_cliente;
    }

    public void setDNI_cliente(String DNI_cliente) {
        this.DNI_cliente = DNI_cliente;
    }

    public String getCorreo_cliente() {
        return Correo_cliente;
    }

    public void setCorreo_cliente(String Correo_cliente) {
        this.Correo_cliente = Correo_cliente;
    }

    public String getTelefono_cliente() {
        return Telefono_cliente;
    }

    public void setTelefono_cliente(String Telefono_cliente) {
        this.Telefono_cliente = Telefono_cliente;
    }
    
}

package datos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import modelos.Cliente;

public class ClienteDAO {

    private static final String SQL_SELECT = "SELECT idcliente,Nom_cliente,DNI_cliente,Correo_cliente,Telefono_cliente FROM cliente";
    private static final String SQL_SELECT_BY_ID = "SELECT  idcliente,Nom_cliente,DNI_cliente,Correo_cliente,Telefono_cliente FROM cliente WHERE idcliente=?";
    private static final String SQL_INSERT = "INSERT INTO cliente(Nom_cliente,DNI_cliente,Correo_cliente,Telefono_cliente) VALUES(?,?,?,?)";
    private static final String SQL_UPDATE = "UPDATE cliente set Nom_cliente=?,DNI_cliente=?,Correo_cliente=?,Telefono_cliente=? WHERE idcliente=? ";
    private static final String SQL_DELETE = "DELETE FROM cliente WHERE idcliente=?";

    public List<Cliente> listar() {
        Connection conn = null;
        PreparedStatement stm = null;
        ResultSet rs = null;
        List<Cliente> clientes = new ArrayList<>();
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = Conexion.getConnection();
            stm = conn.prepareStatement(SQL_SELECT);
            rs = stm.executeQuery();

            while (rs.next()) {
                int idcliente = rs.getInt("idcliente");
                String Nom_cliente = rs.getString("nom_cliente");
                String DNI_cliente = rs.getString("DNI_cliente");
                String Correo_cliente = rs.getString("correo_cliente");
                String Telefono_cliente = rs.getString("telefono_cliente");

                System.out.println(idcliente + " " + Nom_cliente + " " + DNI_cliente + " " + Correo_cliente + " " + Telefono_cliente);
                clientes.add(new Cliente(idcliente, Nom_cliente, DNI_cliente, Correo_cliente, Telefono_cliente));
            }
        } catch (Exception e) {
            e.printStackTrace(System.out);
        } finally {
            Conexion.Close(rs);
            Conexion.Close(stm);
            Conexion.Close(conn);
        }
        return clientes;
    }

    public static void main(String[] args) {
        ClienteDAO cliente = new ClienteDAO();
        cliente.listar();
    }

    public int editar(Cliente cliente) {
        Connection conn = null;
        PreparedStatement stm = null;
        int resultado = 0;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = Conexion.getConnection();
            stm = conn.prepareStatement(SQL_UPDATE);
            stm.setString(1, cliente.getNom_cliente());
            stm.setString(2, cliente.getDNI_cliente());
            stm.setString(3, cliente.getCorreo_cliente());
            stm.setString(4, cliente.getTelefono_cliente());
            stm.setInt(5, cliente.getIdcliente());

            resultado = stm.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace(System.out);
        } finally {
            Conexion.Close(stm);
            Conexion.Close(conn);
        }
        return resultado;
    }

    public int eliminar(Cliente cliente) {
        Connection conn = null;
        PreparedStatement stm = null;
        int resultado = 0;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = Conexion.getConnection();
            stm = conn.prepareStatement(SQL_DELETE);
            stm.setInt(1, cliente.getIdcliente());

            resultado = stm.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace(System.out);
        } finally {
            Conexion.Close(stm);
            Conexion.Close(conn);
        }
        return resultado;

    }
     public int insertar(Cliente cliente) {
        Connection conn = null;
        PreparedStatement stm = null;
        int resultado = 0;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = Conexion.getConnection();
            stm = conn.prepareStatement(SQL_INSERT);
            stm.setString(1, cliente.getNom_cliente());
            stm.setString(2, cliente.getDNI_cliente());
            stm.setString(3, cliente.getCorreo_cliente());
            stm.setString(4, cliente.getTelefono_cliente());


            resultado = stm.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace(System.out);
        } finally {
            Conexion.Close(stm);
            Conexion.Close(conn);
        }
        return resultado;
    }
     public Cliente buscar(Cliente cliente) {
        Connection conn = null;
        PreparedStatement stm = null;
        ResultSet rs = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = Conexion.getConnection();
            stm = conn.prepareStatement(SQL_SELECT_BY_ID);
            stm.setInt(1, cliente.getIdcliente());
            rs = stm.executeQuery();
            rs.next();
            String Nom_cliente = rs.getString("Nom_cliente");
            String DNI_cliente = rs.getString("DNI_cliente");
            String Correo_cliente = rs.getString("Correo_cliente");
            String Telefono_cliente = rs.getString("Telefono_cliente");

            cliente.setNom_cliente(Nom_cliente);
            cliente.setDNI_cliente(DNI_cliente);
            cliente.setCorreo_cliente(Correo_cliente);
            cliente.setTelefono_cliente(Telefono_cliente);
        } catch (Exception e) {
            e.printStackTrace(System.out);
        } finally {
            Conexion.Close(rs);
            Conexion.Close(stm);
            Conexion.Close(conn);
        }
        return cliente;
    }

}

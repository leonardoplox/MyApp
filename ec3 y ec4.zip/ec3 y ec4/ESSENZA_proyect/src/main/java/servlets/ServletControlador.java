package servlets;

import com.mysql.cj.xdevapi.Client;
import datos.ClienteDAO;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import modelos.Cliente;

@WebServlet(name = "ServletControlador", urlPatterns = {"/ServletControlador"})
public class ServletControlador extends HttpServlet {

     @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String accion = request.getParameter("accion");
        if (accion != null) {
            switch (accion) {
                case "editar":
                    this.editarCliente(request, response);
                    break;
                case "eliminar":
                    this.eliminarClientes(request, response);
                    break;
                default:
                    this.listarClientes(request, response);
            }
        } else {
            this.listarClientes(request, response);
        }
    }
   @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String accion = request.getParameter("accion");
        if(accion!=null){
            switch(accion){
                case "insertar": 
                    this.insertarCliente(request, response); break;
                case "modificar": 
                    this.modificarCliente(request, response); break;
                default: this.listarClientes(request,response);
            }
        } 
    }
    
    protected void listarClientes(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<Cliente> clientes = new ClienteDAO().listar();
        HttpSession sesion = request.getSession();
        sesion.setAttribute("clientes", clientes);
        response.sendRedirect("clientes.jsp");
    }
    protected void editarCliente(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
        int idcliente = Integer.parseInt(request.getParameter("idcliente"));
        Cliente cliente = new ClienteDAO().buscar(new Cliente(idcliente));
        request.setAttribute("cliente", cliente);
        String editarjsp = "WEB-INF/paginas/cliente/editarCliente.jsp";
        request.getRequestDispatcher(editarjsp).forward(request, response);
    }
    
    protected void modificarCliente(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int idcliente = Integer.parseInt(request.getParameter("idcliente"));
        String Nom_cliente = request.getParameter("nom_cliente");
        String DNI_cliente = request.getParameter("DNI_cliente");
        String Correo_cliente = request.getParameter("correo_cliente");
        String Telefono_cliente = request.getParameter("telefono_cliente");
        
        Cliente cliente = new Cliente(idcliente, Nom_cliente, DNI_cliente, Correo_cliente, Telefono_cliente);
        int resultado = new ClienteDAO().editar(cliente);
        this.listarClientes(request, response);
    }
    protected void eliminarClientes(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int idcliente = Integer.parseInt(request.getParameter("idcliente"));
        Cliente cliente = new Cliente(idcliente);
        int resultado = new ClienteDAO().eliminar(cliente);
        this.listarClientes(request, response);
    }
    
    protected void insertarCliente(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
            //int idpersona
            String Nom_cliente = request.getParameter("nom_cliente");
            String DNI_cliente = request.getParameter("DNI_cliente");
            String Correo_cliente = request.getParameter("correo_cliente");
            String Telefono_cliente = request.getParameter("telefono_cliente");
            
            Cliente cliente = new Cliente(Nom_cliente,DNI_cliente, Correo_cliente, Telefono_cliente);
            int registroInsertado = new ClienteDAO().insertar(cliente);
            this.listarClientes(request, response);
    }

}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class productoBD {
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    
    
    public boolean nuevoproducto(producto pl){
            String sql =  "INSERT INTO productos (tipoproducto, medidaproducto, modeloproducto, marcaproducto, precio, cantidades) VALUES (?, ?, ?, ?, ?, ?)";
            try {
             con = cn.getConnection();
             ps = con.prepareStatement(sql);
             ps.setString(1, pl.getTipoproducto());
             ps.setString(2, pl.getMedidaproducto());
             ps.setString(3, pl.getModeloproducto());
             ps.setString(4, pl.getMarca());
             ps.setInt(5, pl.getPrecio());
             ps.setInt(6, pl.getCantidades());
             ps.executeUpdate();
             return true;
                
           
        } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, e.toString());
                return false;
        }finally{
                try {
                    con.close();
                } catch (SQLException e) {
                      System.out.println(e.toString());
                }
                
            }
            }
    
    
            public List ListarProducto(){
                List<producto> Listapo = new ArrayList <>();
                String sql = "SELECT * FROM productos";
                try {
                    con = cn.getConnection();
                    ps = con.prepareStatement(sql);
                    rs = ps.executeQuery();
                    
                    while (rs.next()){
                        producto po = new producto();
                        po.setTipoproducto(rs.getString("tipoproducto"));
                        po.setMedidaproducto(rs.getString("medidaproducto"));
                        po.setModeloproducto(rs.getString("modeloproducto"));
                        po.setMarca(rs.getString("marcaproducto"));
                        po.setPrecio(rs.getInt("precio"));
                        po.setCantidades(rs.getInt("cantidades"));
                        Listapo.add(po);
                        
                    }
                } catch (SQLException e) {
                    System.out.println(e.toString());
                }
                return Listapo;
            }
               
                
                
    
}
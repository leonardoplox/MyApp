package pe.com.empresa.vista;

/**
 *
 * @author Daniel Levano
 */
public class Index {
    public static void inicio(){
        IndexPrincipal.inicio();
    }
    public static void main(String[] args) {
        inicio();
    }
}

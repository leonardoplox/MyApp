/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class productoBD {
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    
    
    public boolean nuevoproducto(producto pl){
            String sql =  "INSERT INTO productos (id, tipoproducto, medidaproducto, modeloproducto, marcaproducto, precio, cantidades) VALUES (?, ?, ?, ?, ?, ?, ?)";
            try {
             con = cn.getConnection();
             ps = con.prepareStatement(sql);
             ps.setInt(1, pl.getId());
             ps.setString(2, pl.getTipoproducto());
             ps.setString(3, pl.getMedidaproducto());
             ps.setString(4, pl.getModeloproducto());
             ps.setString(5, pl.getMarca());
             ps.setInt(6, pl.getPrecio());
             ps.setInt(7, pl.getCantidades());
             ps.executeUpdate();
             return true;
                
           
        } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, e.toString());
                return false;
        }finally{
                try {
                    con.close();
                } catch (SQLException e) {
                      System.out.println(e.toString());
                }
                
            }
            }
    
    
            public List ListarProducto(){
                List<producto> Listapo = new ArrayList <>();
                String sql = "SELECT * FROM productos";
                try {
                    con = cn.getConnection();
                    ps = con.prepareStatement(sql);
                    rs = ps.executeQuery();
                    
                    while (rs.next()){
                        producto po = new producto();
                        po.setId(rs.getInt("id"));
                        po.setTipoproducto(rs.getString("tipoproducto"));
                        po.setMedidaproducto(rs.getString("medidaproducto"));
                        po.setModeloproducto(rs.getString("modeloproducto"));
                        po.setMarca(rs.getString("marcaproducto"));
                        po.setPrecio(rs.getInt("precio"));
                        po.setCantidades(rs.getInt("cantidades"));
                        Listapo.add(po);
                        
                    }
                } catch (SQLException e) {
                    System.out.println(e.toString());
                }
                return Listapo;
            }
            
            
        public List<producto> buscarProducto(String terminoBusqueda) {
    List<producto> Listapo = new ArrayList<>();
    String sql = "SELECT * FROM productos WHERE tipoproducto LIKE ?";
    
    try {
        con = cn.getConnection();
        ps = con.prepareStatement(sql);
        String query = "%" + terminoBusqueda + "%";
        ps.setString(1, query);
        rs = ps.executeQuery();
        
        while (rs.next()) {
            producto po = new producto();
            po.setId(rs.getInt("id"));
            po.setTipoproducto(rs.getString("tipoproducto"));
            po.setMedidaproducto(rs.getString("medidaproducto"));
            po.setModeloproducto(rs.getString("modeloproducto"));
            po.setMarca(rs.getString("marcaproducto"));
            po.setPrecio(rs.getInt("precio"));
            po.setCantidades(rs.getInt("cantidades"));
            Listapo.add(po);
        }
    } catch (SQLException e) {
        System.out.println(e.toString());
    } finally {
        try {
            con.close();
        } catch (SQLException e) {
            System.out.println(e.toString());
        }
    }
    
    return Listapo;
    }     
         
        

      
                
          public boolean eliminarProductoPorTipo(int id) {
    String sql = "DELETE FROM productos WHERE id = ?";
    try {
        con = cn.getConnection();
        ps = con.prepareStatement(sql);
        ps.setInt(1, id);
        ps.executeUpdate();
        return true;
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, e.toString());
        return false;
    } finally {
        try {
            con.close();
        } catch (SQLException e) {
            System.out.println(e.toString());
            
        }
    }
}      
    
          
           public boolean agregarInventario(int productoId, int cantidadAgregar) {
        String sql = "UPDATE productos SET cantidades = cantidades + ? WHERE id = ?";
        try {
            con = cn.getConnection(); // Usa la conexión de la clase Conexion
            ps = con.prepareStatement(sql);
            ps.setInt(1, cantidadAgregar);
            ps.setInt(2, productoId);
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
            return false;
        } finally {
            try {
                if (ps != null) ps.close();
                if (con != null) con.close();
            } catch (SQLException e) {
                System.out.println(e.toString());
            }
        }
    }


public int obtenerCantidadProducto(int idProducto) {
    int cantidad = 0;
    Connection con = null;
    PreparedStatement pst = null;
    ResultSet rs = null;

    try {
        con = cn.getConnection();
        String sql = "SELECT cantidades FROM productos WHERE id = ?";
        pst = con.prepareStatement(sql);
        pst.setInt(1, idProducto);
        rs = pst.executeQuery();

        if (rs.next()) {
            cantidad = rs.getInt("cantidades");
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error al obtener la cantidad del producto: " + e.getMessage());
    } finally {
        try {
            if (rs != null) rs.close();
            if (pst != null) pst.close();
            if (con != null) con.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al cerrar la conexión: " + e.getMessage());
        }
    }
    
    return cantidad;
}
  
public boolean disminuirInventario(int productoId, int cantidadDisminuir) {
    Connection con = null;
    PreparedStatement pst = null;
    ResultSet rs = null;
    boolean exito = false;

    try {
        con = cn.getConnection();

        // Consultar la cantidad actual del producto
        String querySelect = "SELECT cantidades FROM productos WHERE id = ?";
        pst = con.prepareStatement(querySelect);
        pst.setInt(1, productoId);
        rs = pst.executeQuery();

        if (rs.next()) {
            int cantidadActual = rs.getInt("cantidades");

            // Verificar si la cantidad actual es suficiente
            if (cantidadActual >= cantidadDisminuir) {
                // Preparar la actualización
                String queryUpdate = "UPDATE productos SET cantidades = cantidades - ? WHERE id = ?";
                pst = con.prepareStatement(queryUpdate);
                pst.setInt(1, cantidadDisminuir);
                pst.setInt(2, productoId);
                pst.executeUpdate();
                exito = true;
                JOptionPane.showMessageDialog(null, "Unidades disminuidas exitosamente.");
            } else {
                JOptionPane.showMessageDialog(null, "No se puede disminuir la cantidad. El inventario no puede ser negativo.");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Producto con ID " + productoId + " no encontrado.");
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error al disminuir unidades: " + e.getMessage());
    } finally {
        try {
            if (rs != null) rs.close();
            if (pst != null) pst.close();
            if (con != null) con.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al cerrar la conexión: " + e.getMessage());
        }
    }

    return exito;
}




}

          
          
          
          
          

package VistasSecundarias;

import Modelo.Conexion;
import Modelo.historialventaBD;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import java.awt.*;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.SQLException;

public class HistorialVentaFrame extends JPanel {

    private JTable tableHistorial;
    private DefaultTableModel tableModel;
    private JButton botonHistorial, botonCancelar;
    private Conexion conexion;
    private historialventaBD historialBD;

    public HistorialVentaFrame() {
        // Configuración del JPanel
        setLayout(new BorderLayout());

        // Crear y configurar el JTable y su modelo
        String[] columnNames = {"ID","Cliente", "Producto", "Precio Total", "Método de Pago", "Fecha y Hora", "Estado"};
        tableModel = new DefaultTableModel(columnNames, 0);
        tableHistorial = new JTable(tableModel) {
            @Override
            public Component prepareRenderer(TableCellRenderer renderer, int row, int column) {
                Component comp = super.prepareRenderer(renderer, row, column);
                if (column == 1) { // Índice de la columna Producto
                    comp.setPreferredSize(new Dimension(600, comp.getPreferredSize().height)); // Ajusta el tamaño de la columna Producto
                }
                return comp;
            }
        };

        // Configurar el tamaño de fuente y altura de las filas
        tableHistorial.setFont(new Font("Arial", Font.PLAIN, 14));
        tableHistorial.setRowHeight(90);

        tableHistorial.setFillsViewportHeight(true);
        tableHistorial.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);

        // Ajustar el ancho de las columnas
        tableHistorial.getColumnModel().getColumn(0).setPreferredWidth(20);
        tableHistorial.getColumnModel().getColumn(1).setPreferredWidth(150);
        tableHistorial.getColumnModel().getColumn(2).setPreferredWidth(600);
        tableHistorial.getColumnModel().getColumn(3).setPreferredWidth(150);
        tableHistorial.getColumnModel().getColumn(4).setPreferredWidth(150);
        tableHistorial.getColumnModel().getColumn(5).setPreferredWidth(150);
        tableHistorial.getColumnModel().getColumn(6).setPreferredWidth(150);

        // Configurar el renderer para la columna del producto
        tableHistorial.getColumnModel().getColumn(1).setCellRenderer(new MultiLineCellRenderer());

        // Configurar el JScrollPane
        JScrollPane scrollPane = new JScrollPane(tableHistorial);
        scrollPane.setPreferredSize(new Dimension(1000, 600));

        // Crear y configurar el botón "Actualizar Historial"
        botonHistorial = new JButton("Actualizar Historial");
        botonHistorial.addActionListener(e -> loadHistorialData());

        // Crear y configurar el botón "Cancelar Venta"
        botonCancelar = new JButton("Cancelar Venta");
        botonCancelar.addActionListener(e -> cancelarVentaSeleccionada());

        // Añadir el JScrollPane y los botones al JPanel
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(botonHistorial);
        buttonPanel.add(botonCancelar);
        add(scrollPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        // Instanciar las clases de conexión y BD
        conexion = new Conexion();
        historialBD = new historialventaBD();

        // Cargar los datos inicialmente
        loadHistorialData();
    }

    private void loadHistorialData() {
        String query = "SELECT * FROM historialventa"; // Cambia esto por el nombre correcto de tu tabla

        try (Connection connection = conexion.getConnection();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {

            // Limpiar el modelo antes de cargar nuevos datos
            tableModel.setRowCount(0);

            // Procesar el ResultSet y añadir datos al DefaultTableModel
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String cliente = resultSet.getString("cliente");
                String producto = resultSet.getString("producto");
                double precioTotal = resultSet.getDouble("preciototal");
                String metodoDePago = resultSet.getString("metododepago");
                String fechaYHora = resultSet.getString("fechayhora");
                String estado = resultSet.getString("estado");
                // Añadir una fila a la tabla
                tableModel.addRow(new Object[]{id, cliente, producto, precioTotal, metodoDePago, fechaYHora, estado});
            }

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al cargar los datos: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void cancelarVentaSeleccionada() {
     int selectedRow = tableHistorial.getSelectedRow();
    if (selectedRow != -1) {
        // Obtener el ID de la venta seleccionada
        Object idObject = tableModel.getValueAt(selectedRow, 0); // Obtener el ID de la venta
        int id;
        try {
            if (idObject instanceof Integer) {
                id = (Integer) idObject;
            } else if (idObject instanceof String) {
                id = Integer.parseInt((String) idObject);
            } else {
                throw new NumberFormatException("El ID no es válido");
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "El ID seleccionado no es válido.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String estadoActual = (String) tableModel.getValueAt(selectedRow, 6); // Obtener el estado actual

        // Verificar que el estado de la venta sea "Vendido" antes de cancelar
        if ("Vendido".equals(estadoActual)) {
            // Actualizar el estado a "Cancelado"
            historialBD.actualizarEstadoVenta(id, "Cancelado");

            // Obtener el nombre del producto y la cantidad vendida
            String producto = (String) tableModel.getValueAt(selectedRow, 1); // Obtener el nombre del producto
            Object cantidadObject = tableModel.getValueAt(selectedRow, 3); // Obtener la cantidad vendida

            // Convertir la cantidad a Integer si es necesario
            int cantidadVendida;
            if (cantidadObject instanceof Integer) {
                cantidadVendida = (Integer) cantidadObject;
            } else if (cantidadObject instanceof Double) {
                cantidadVendida = ((Double) cantidadObject).intValue();
            } else {
                JOptionPane.showMessageDialog(this, "La cantidad vendida no es válida.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Obtener el ID del producto
            int productoid = historialBD.obtenerIdDelProducto(producto);

            if (productoid != -1) {
                // Devolver el producto al inventario
                historialBD.devolverProductosAlInventario(productoid, cantidadVendida);
                loadHistorialData(); // Recargar los datos para reflejar los cambios

                JOptionPane.showMessageDialog(this, "La venta ha sido cancelada y el producto devuelto al inventario.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            } else {
                // Mostrar información de depuración
                JOptionPane.showMessageDialog(this, "El producto '" + producto + "' no se encontró en el inventario.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, "La venta seleccionada no está en estado 'Vendido'.", "Advertencia", JOptionPane.WARNING_MESSAGE);
        }
    } else {
        JOptionPane.showMessageDialog(this, "Por favor, selecciona una venta para cancelar.", "Advertencia", JOptionPane.WARNING_MESSAGE);
    }
}

    // Clase para el renderizador de celdas multilínea
    class MultiLineCellRenderer extends JTextArea implements TableCellRenderer {

        public MultiLineCellRenderer() {
            setLineWrap(true);
            setWrapStyleWord(true);
            setOpaque(true);
        }

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            setText(value.toString());
            if (isSelected) {
                setBackground(table.getSelectionBackground());
                setForeground(table.getSelectionForeground());
            } else {
                setBackground(table.getBackground());
                setForeground(table.getForeground());
            }
            // Ajustar el tamaño de la celda para mostrar hasta 6 líneas de texto
            int lines = getLineCount();
            int height = getPreferredSize().height;
            table.setRowHeight(row, Math.max(height, 90)); // Ajusta la altura de la fila
            return this;
        }
    }







    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablahistorial = new javax.swing.JTable();

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tablahistorial.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tablahistorial);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 110, 880, 590));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 880, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tablahistorial;
    // End of variables declaration//GEN-END:variables
}

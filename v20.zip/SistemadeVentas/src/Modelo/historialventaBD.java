/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;



import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import java.sql.ResultSet;
public class historialventaBD {
    private Conexion cn = new Conexion();

    public void insertarHistorialVenta(String cliente, String producto, double precioTotal, String metodoDePago, String fechaYHora, String Estado) {
        String sql = "INSERT INTO historialventa (fechayhora,cliente,producto,preciototal,metododepago, Estado) VALUES (?, ?, ?, ?, ?, ?)";
        
        try (Connection con = cn.getConnection(); 
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, fechaYHora); // Asignar la fecha y hora
            ps.setString(2, cliente);
            ps.setString(3, producto);
            ps.setDouble(4, precioTotal);
            ps.setString(5, metodoDePago);
            ps.setString(6, Estado);
            
            ps.executeUpdate();
            
        } catch (SQLException e) {
            e.printStackTrace();
            // Aquí podrías agregar más detalles del error si es necesario
        }
    }
    
    public void actualizarEstadoVenta(int id, String nuevoEstado) {
        String sql = "UPDATE historialventa SET Estado = ? WHERE id = ?";
        
        try (Connection con = cn.getConnection(); 
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, nuevoEstado);
            ps.setInt(2, id);
            
            ps.executeUpdate();
            int rowsAffected = ps.executeUpdate();
        if (rowsAffected == 0) {
            JOptionPane.showMessageDialog(null, "No se encontró una venta con el ID especificado.", "Error", JOptionPane.ERROR_MESSAGE);
        }
            
        } catch (SQLException e) {
            e.printStackTrace();
            // Manejo de errores
        }
    }

    // Método para devolver productos al inventario
    public void devolverProductosAlInventario(int productoid, int cantidad) {
    String sql = "UPDATE productos SET cantidades = cantidades + ? WHERE id = ?";
        
        try (Connection con = cn.getConnection(); 
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, cantidad);
            ps.setInt(2, productoid);
            
            ps.executeUpdate();
            
        } catch (SQLException e) {
            e.printStackTrace();
            // Manejo de errores
        }
    }
    public int obtenerIdDelProducto(String tipoproducto) {
     String sql = "SELECT id FROM productos WHERE tipoproducto = ?";
    int id = -1;

    try (Connection con = cn.getConnection(); 
         PreparedStatement ps = con.prepareStatement(sql)) {
        ps.setString(1, tipoproducto);

        try (ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                id = rs.getInt("id");
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
        // Manejo de errores
    }

    return id;
}
    
}

    


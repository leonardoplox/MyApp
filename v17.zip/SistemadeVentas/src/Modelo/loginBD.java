
package Modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class loginBD {
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    Conexion cn = new Conexion();
    
     public login log(String usuario, String contraseña, String rol) {
        login lg = null;
        // Aquí deberías conectar con la base de datos y verificar el usuario, contraseña y rol
        try (Connection con = cn.getConnection()) {
            String query = "SELECT * FROM usuarios WHERE usuario = ? AND contraseña = ? AND rol = ?";
            try (PreparedStatement ps = con.prepareStatement(query)) {
                ps.setString(1, usuario);
                ps.setString(2, contraseña);
                ps.setString(3, rol);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        lg = new login();
                        lg.setUsuario(rs.getString("usuario"));
                        lg.setContraseña(rs.getString("contraseña"));
                        lg.setRol(rs.getString("rol"));
                    }
                }
            }
        } catch (SQLException e) {
        }
        return lg;
    }
}


/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author eeeca
 */
public class producto {
    
    private int id;
    private String tipoproducto;
    private String medidaproducto;
    private String modeloproducto;
    private String marca;
    private int Precio;
    private int cantidades;

    public producto() {
    }

    public producto(int id, String tipoproducto, String medidaproducto, String modeloproducto, String marca, int Precio, int cantidades) {
        this.id = id;
        this.tipoproducto = tipoproducto;
        this.medidaproducto = medidaproducto;
        this.modeloproducto = modeloproducto;
        this.marca = marca;
        this.Precio = Precio;
        this.cantidades = cantidades;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTipoproducto() {
        return tipoproducto;
    }

    public void setTipoproducto(String tipoproducto) {
        this.tipoproducto = tipoproducto;
    }

    public String getMedidaproducto() {
        return medidaproducto;
    }

    public void setMedidaproducto(String medidaproducto) {
        this.medidaproducto = medidaproducto;
    }

    public String getModeloproducto() {
        return modeloproducto;
    }

    public void setModeloproducto(String modeloproducto) {
        this.modeloproducto = modeloproducto;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public int getPrecio() {
        return Precio;
    }

    public void setPrecio(int Precio) {
        this.Precio = Precio;
    }

    public int getCantidades() {
        return cantidades;
    }

    public void setCantidades(int cantidades) {
        this.cantidades = cantidades;
    }

    
   
    
    
    
}

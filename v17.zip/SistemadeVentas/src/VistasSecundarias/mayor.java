/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package VistasSecundarias;

import Modelo.producto;
import Modelo.productoBD;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.File;

import javax.swing.table.TableModel;
import javax.swing.JTable;
import java.io.FileOutputStream;
import java.io.IOException;

public class mayor extends javax.swing.JPanel {

    DefaultTableModel modelo;
    producto p1 = new producto();
    productoBD pro = new productoBD();
    
   
public mayor() {
    initComponents();
    modelo = new DefaultTableModel();
    modelo.addColumn("Contenido");
    modelo.addColumn("Cantidad");
    modelo.addColumn("Precio");
    DefaultTableModel modelo = new DefaultTableModel(
        new Object [][] {},
        new String [] {"ID", "Tipo", "Medida", "Modelo", "Marca", "Precio", "Unidades"}
    ) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false; // No permitir edición en ninguna celda
        }
    };
    tablabuscar.setModel(modelo);
    
    // Agregar el KeyListener después de inicializar los componentes
    txtbuscar.addKeyListener(new java.awt.event.KeyAdapter() {
        public void keyPressed(java.awt.event.KeyEvent evt) {
            txtbuscarKeyPressed(evt);
        }
    });

    // Agregar el ListSelectionListener
    tablabuscar.getSelectionModel().addListSelectionListener(e -> {
        if (!e.getValueIsAdjusting()) { // Solo responde cuando la selección ha terminado
            int selectedRow = tablabuscar.getSelectedRow();
            if (selectedRow >= 0) {
                // Obtener el valor del precio (columna 5) y actualizar el JTextField
                String precioSeleccionado = tablabuscar.getValueAt(selectedRow, 5).toString();
                mostrarprecio.setText(precioSeleccionado);
                actualizarTotal();
            }
        }
    });
    
    // Agregar DocumentListener a los JTextFields cantidad y mostrarprecio
    cantidad.getDocument().addDocumentListener(new DocumentListener() {
        public void changedUpdate(DocumentEvent e) {
            actualizarTotal();
        }
        public void removeUpdate(DocumentEvent e) {
            actualizarTotal();
        }
        public void insertUpdate(DocumentEvent e) {
            actualizarTotal();
        }
    });

    mostrarprecio.getDocument().addDocumentListener(new DocumentListener() {
        public void changedUpdate(DocumentEvent e) {
            actualizarTotal();
        }
        public void removeUpdate(DocumentEvent e) {
            actualizarTotal();
        }
        public void insertUpdate(DocumentEvent e) {
            actualizarTotal();
        }
    });
}

// Método para actualizar el valor de txtfinal
private void actualizarTotal() {
    try {
        int cant = Integer.parseInt(cantidad.getText());
        double precio = Double.parseDouble(mostrarprecio.getText());
        double total = cant * precio;
        txtfinal.setText(String.valueOf(total));
    } catch (NumberFormatException e) {
        txtfinal.setText("0"); // Manejar el caso donde el contenido no es un número válido
    }
}

    public void ListarProducto(){
        List<producto> Listarpo = pro.ListarProducto();
        modelo = (DefaultTableModel) tablabuscar.getModel();
        modelo.setRowCount(0);
        Object[] ob = new Object[6];
        for (int i = 0; i < Listarpo.size(); i++){
            
            ob [0] = Listarpo.get(i).getId();
            ob [1] = Listarpo.get(i).getTipoproducto();
            ob [2] = Listarpo.get(i).getMedidaproducto();
            ob [3] = Listarpo.get(i).getModeloproducto();
            ob [4] = Listarpo.get(i).getMarca();
            ob [5] = Listarpo.get(i).getCantidades();
            modelo.addRow(ob);
 
        }
    tablabuscar.setModel(modelo);
    
    }   
        
    private void actualizarTabla(List<producto> resultados) {
    DefaultTableModel modelo = (DefaultTableModel) tablabuscar.getModel();
    modelo.setRowCount(0); // Limpiar la tabla existente
    
    Object[] ob = new Object[7];
    for (producto po : resultados) {
        ob[0] = po.getId();
        ob[1] = po.getTipoproducto();
        ob[2] = po.getMedidaproducto();
        ob[3] = po.getModeloproducto();
        ob[4] = po.getMarca();
        ob[5] = po.getPrecio();
        ob[6] = po.getCantidades();
        modelo.addRow(ob);
    }
    tablabuscar.setModel(modelo);
}
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        txtUsuario = new javax.swing.JTextField();
        productolista = new javax.swing.JDialog();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tablabuscar = new javax.swing.JTable();
        botonbuscar = new javax.swing.JButton();
        txtbuscar = new javax.swing.JTextField();
        botonseleccionar = new javax.swing.JButton();
        cantidad = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        mostrarprecio = new javax.swing.JTextField();
        txtfinal = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        precioprecio = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();
        contenido = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtNombreCliente = new javax.swing.JTextField();
        terminar = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        txtprecio = new javax.swing.JTextField();
        txtDNI = new javax.swing.JTextField();
        jComboBox1 = new javax.swing.JComboBox<>();
        jSeparator1 = new javax.swing.JSeparator();
        jSeparator4 = new javax.swing.JSeparator();
        jPanel2 = new javax.swing.JPanel();
        jSeparator7 = new javax.swing.JSeparator();
        jSeparator8 = new javax.swing.JSeparator();
        jLabel6 = new javax.swing.JLabel();
        jComboBox2 = new javax.swing.JComboBox<>();
        botonbus = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        tablagos = new javax.swing.JTable();
        elim = new javax.swing.JButton();

        txtUsuario.setBorder(null);

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tablabuscar.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Tipo", "Medida", "Modelo", "Marca", "Precio", "Unidades"
            }
        ));
        jScrollPane2.setViewportView(tablabuscar);

        jPanel4.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 120, 800, 430));

        botonbuscar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        botonbuscar.setText("Buscar");
        botonbuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonbuscarActionPerformed(evt);
            }
        });
        jPanel4.add(botonbuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 70, 90, 40));

        txtbuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtbuscarActionPerformed(evt);
            }
        });
        jPanel4.add(txtbuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 90, 170, -1));

        botonseleccionar.setBackground(new java.awt.Color(255, 153, 0));
        botonseleccionar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        botonseleccionar.setText("AGREGAR");
        botonseleccionar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonseleccionarActionPerformed(evt);
            }
        });
        jPanel4.add(botonseleccionar, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 10, 110, 40));
        jPanel4.add(cantidad, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 10, 80, 30));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel8.setText("CANTIDAD");
        jPanel4.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, 30));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setText("PRECIO BASE");
        jPanel4.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 20, -1, 20));

        mostrarprecio.setEditable(false);
        mostrarprecio.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        mostrarprecio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mostrarprecioActionPerformed(evt);
            }
        });
        jPanel4.add(mostrarprecio, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 10, 70, 30));

        txtfinal.setEditable(false);
        txtfinal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtfinalActionPerformed(evt);
            }
        });
        jPanel4.add(txtfinal, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 10, 80, 30));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel7.setText("PRECIO SUGERIDO");
        jPanel4.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 20, 160, -1));

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel9.setText("PRECIO FINAL");
        jPanel4.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 80, -1, -1));

        precioprecio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                precioprecioActionPerformed(evt);
            }
        });
        jPanel4.add(precioprecio, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 80, 80, 30));

        jPanel1.setBackground(new java.awt.Color(102, 204, 0));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 420, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        jPanel4.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, -50, 420, -1));

        javax.swing.GroupLayout productolistaLayout = new javax.swing.GroupLayout(productolista.getContentPane());
        productolista.getContentPane().setLayout(productolistaLayout);
        productolistaLayout.setHorizontalGroup(
            productolistaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        productolistaLayout.setVerticalGroup(
            productolistaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        setPreferredSize(new java.awt.Dimension(880, 740));

        contenido.setBackground(new java.awt.Color(255, 255, 255));
        contenido.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel1.setText("Nombre del Cliente:");
        contenido.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 60, -1, 32));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setText("PRECIO FINAL:");
        contenido.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 570, 135, 30));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel3.setText("PRODUCTO:");
        contenido.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 240, 135, 32));

        txtNombreCliente.setBorder(null);
        contenido.add(txtNombreCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(217, 70, 290, 20));

        terminar.setBackground(new java.awt.Color(255, 153, 51));
        terminar.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        terminar.setForeground(new java.awt.Color(255, 255, 255));
        terminar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/nuevo.png"))); // NOI18N
        terminar.setText("TERMINAR");
        terminar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        terminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                terminarActionPerformed(evt);
            }
        });
        contenido.add(terminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 660, 174, 55));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel5.setText("VENTA A MENOR");
        contenido.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 6, 311, 46));

        txtprecio.setBorder(null);
        txtprecio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtprecioActionPerformed(evt);
            }
        });
        contenido.add(txtprecio, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 570, 160, 20));

        txtDNI.setBorder(null);
        txtDNI.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtDNIActionPerformed(evt);
            }
        });
        contenido.add(txtDNI, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 120, 290, 20));

        jComboBox1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "DNI", "PASAPORTE", "CARNE DE EXTRANJERIA", "PASAPORTE", " " }));
        jComboBox1.setBorder(null);
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });
        contenido.add(jComboBox1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 120, 160, -1));
        contenido.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 250, -1, -1));
        contenido.add(jSeparator4, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 140, 290, 10));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        contenido.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 240, -1, -1));
        contenido.add(jSeparator7, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 590, 160, 10));
        contenido.add(jSeparator8, new org.netbeans.lib.awtextra.AbsoluteConstraints(217, 90, 290, 10));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel6.setText("Metodo de Pago:");
        contenido.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 170, -1, -1));

        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Efectivo", "Transferencia ", "Tarjeta Debito/Credito", "Yape", "Plin" }));
        contenido.add(jComboBox2, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 170, 150, 30));

        botonbus.setText("Agregar Producto");
        botonbus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonbusActionPerformed(evt);
            }
        });
        contenido.add(botonbus, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 240, 130, 30));

        tablagos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Tipo", "Medida", "Modelo", "Marca", "Unidades", "Precio"
            }
        ));
        jScrollPane3.setViewportView(tablagos);

        contenido.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 310, 570, 230));

        elim.setBackground(new java.awt.Color(255, 0, 0));
        elim.setForeground(new java.awt.Color(255, 255, 255));
        elim.setText("Eliminar de la Lista");
        elim.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                elimActionPerformed(evt);
            }
        });
        contenido.add(elim, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 360, -1, 60));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(contenido, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 892, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(contenido, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 750, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents
  
    private void botonbuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonbuscarActionPerformed

        
        String terminoBusqueda = txtbuscar.getText();
        List<producto> resultados = pro.buscarProducto(terminoBusqueda);
        actualizarTabla(resultados);
        
    }//GEN-LAST:event_botonbuscarActionPerformed

    private void txtbuscarKeyPressed(java.awt.event.KeyEvent evt) {
    if (evt.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER) {
        String terminoBusqueda = txtbuscar.getText();
        List<producto> resultados = pro.buscarProducto(terminoBusqueda);
        actualizarTabla(resultados);
    }
    }
    private void txtbuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtbuscarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtbuscarActionPerformed
private void actualizarPrecioTotal() {
    DefaultTableModel modeloTablagos = (DefaultTableModel) tablagos.getModel();
    double total = 0;
    
    // Recorrer las filas de la tabla y sumar los precios
    for (int i = 0; i < modeloTablagos.getRowCount(); i++) {
        double precio = (double) modeloTablagos.getValueAt(i, 6); // Columna de precio
        total += precio;
    }
    
    // Actualizar el campo txtprecio con el total
    txtprecio.setText(String.valueOf(total));
    }
    private void botonseleccionarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonseleccionarActionPerformed

        int fsel = tablabuscar.getSelectedRow();
    try {
        String ID, Tipo, Medida, Modelo, Marca;
        int Unidades;
        double Precio, PrecioTotal, PrecioMinimo;

        if (fsel == -1) {
            JOptionPane.showMessageDialog(null, "Selecciona un Producto");
        } else {
            modelo = (DefaultTableModel) tablabuscar.getModel();
            
            ID = tablabuscar.getValueAt(fsel, 0).toString();
            Tipo = tablabuscar.getValueAt(fsel, 1).toString();
            Medida = tablabuscar.getValueAt(fsel, 2).toString();
            Modelo = tablabuscar.getValueAt(fsel, 3).toString();
            Marca = tablabuscar.getValueAt(fsel, 4).toString();
            Precio = Double.parseDouble(tablabuscar.getValueAt(fsel, 5).toString());
            Unidades = Integer.parseInt(cantidad.getText());
            PrecioMinimo = Double.parseDouble(txtfinal.getText());
            double PrecioFinal = Double.parseDouble(precioprecio.getText());

            // Validar si el precio mínimo es menor que el precio final
            if (PrecioMinimo > PrecioFinal) {
                JOptionPane.showMessageDialog(null, "El precio final no puede ser menor al precio sugerido.");
                return; // Salir del método si hay un error
            }

            PrecioTotal = Precio * Unidades;

            // Agregar el producto a la tabla `tablagos`
            DefaultTableModel modeloTablagos = (DefaultTableModel) tablagos.getModel();
            modeloTablagos.addRow(new Object[]{ID, Tipo, Medida, Modelo, Marca, Unidades, PrecioFinal});

            // Limpiar los campos de cantidad y precio final después de agregar el producto
            cantidad.setText("");
            precioprecio.setText("");

            // Actualizar el precio total si es necesario
            actualizarPrecioTotal();

            productolista.setVisible(false);
        }
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(null, "Error en la conversión de números. Verifica que todos los campos contienen números válidos.");
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Ocurrió un error: " + e.getMessage());
    }
   
    }//GEN-LAST:event_botonseleccionarActionPerformed

    private void botonbusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonbusActionPerformed

        productolista.setSize(800,550);
        productolista.setLocationRelativeTo(null);
        productolista.setModal(true);
        productolista.setVisible(true);

    }//GEN-LAST:event_botonbusActionPerformed

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void txtDNIActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtDNIActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtDNIActionPerformed

    private void txtprecioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtprecioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtprecioActionPerformed

    private void terminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_terminarActionPerformed
    DefaultTableModel modeloTablagos = (DefaultTableModel) tablagos.getModel();
    
    // Procesar cada fila de la tabla "tablagos"
    for (int i = 0; i < modeloTablagos.getRowCount(); i++) {
        try {
            String idProductoStr = modeloTablagos.getValueAt(i, 0).toString();
            int idProducto = Integer.parseInt(idProductoStr);
            String cantidadVentaStr = modeloTablagos.getValueAt(i, 5).toString();
            int cantidadVenta = Integer.parseInt(cantidadVentaStr);
            
            int cantidadActual = pro.obtenerCantidadProducto(idProducto);
            
            if (cantidadVenta > cantidadActual) {
                JOptionPane.showMessageDialog(this, "No hay suficiente stock para el producto ID: " + idProducto, "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            pro.disminuirInventario(idProducto, cantidadVenta);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Error en los datos numéricos. Verifique los valores ingresados.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
    }
    
    // Actualizar la tabla de productos y otras acciones necesarias
    List<producto> productosActualizados = pro.ListarProducto();
    actualizarTabla(productosActualizados);
    
    // Generar el PDF antes de vaciar la tabla
    pdf();
    
    // Vaciar la tabla
    modeloTablagos.setRowCount(0);

    // Mensaje de éxito
    JOptionPane.showMessageDialog(this, "Venta terminada y stock actualizado exitosamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);

    }//GEN-LAST:event_terminarActionPerformed

    private void mostrarprecioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mostrarprecioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_mostrarprecioActionPerformed

    private void precioprecioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_precioprecioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_precioprecioActionPerformed

    private void elimActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_elimActionPerformed
int selectedRow = tablagos.getSelectedRow();
    if (selectedRow >= 0) {
        // Eliminar la fila seleccionada
        DefaultTableModel modelo = (DefaultTableModel) tablagos.getModel();
        modelo.removeRow(selectedRow);
        
        // Actualizar el total en txtprecio
        actualizarTotalTabla();
    } else {
        JOptionPane.showMessageDialog(null, "Seleccione un producto para eliminar.");
    }
}

// Método para actualizar el total en txtprecio basado en las filas restantes de la tabla
private void actualizarTotalTabla() {
    double total = 0.0;
    DefaultTableModel modelo = (DefaultTableModel) tablagos.getModel();
    for (int i = 0; i < modelo.getRowCount(); i++) {
        // Suponiendo que el precio está en la columna 5
        double precio = Double.parseDouble(modelo.getValueAt(i, 6).toString());
        total += precio;
    }
    txtprecio.setText(String.valueOf(total));

    }//GEN-LAST:event_elimActionPerformed

    private void txtfinalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtfinalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtfinalActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botonbus;
    private javax.swing.JButton botonbuscar;
    private javax.swing.JButton botonseleccionar;
    private javax.swing.JTextField cantidad;
    private javax.swing.JPanel contenido;
    private javax.swing.JButton elim;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator7;
    private javax.swing.JSeparator jSeparator8;
    private javax.swing.JTextField mostrarprecio;
    private javax.swing.JTextField precioprecio;
    private javax.swing.JDialog productolista;
    private javax.swing.JTable tablabuscar;
    private javax.swing.JTable tablagos;
    private javax.swing.JButton terminar;
    private javax.swing.JTextField txtDNI;
    private javax.swing.JTextField txtNombreCliente;
    private javax.swing.JTextField txtUsuario;
    private javax.swing.JTextField txtbuscar;
    private javax.swing.JTextField txtfinal;
    private javax.swing.JTextField txtprecio;
    // End of variables declaration//GEN-END:variables


    

private int numeroReporte = 1; // Variable para llevar el control del número de reporte

private void pdf() {
    FileOutputStream archivo = null;
    Document doc = null;
    try {
        // Crear el archivo PDF con el número de reporte
        File file = new File("src/PDF/venta" + String.format("%05d", numeroReporte) + ".pdf");
        archivo = new FileOutputStream(file);
        doc = new Document();
        PdfWriter.getInstance(doc, archivo);
        doc.open();

        // Agregar la imagen del logo
        Image img = Image.getInstance("C:/Users/pepon/Downloads/SistemadeVentas/src/Imagenes/logo1.png");
        img.scaleToFit(140, 120); // Ajusta el tamaño de la imagen si es necesario
        img.setAlignment(Image.ALIGN_CENTER);
        doc.add(img);

        // Agregar encabezado
        Paragraph encabezado = new Paragraph("BOLETA DE VENTA", new Font(Font.FontFamily.TIMES_ROMAN, 18, Font.BOLD, BaseColor.BLACK));
        encabezado.setAlignment(Element.ALIGN_CENTER);
        doc.add(encabezado);
        doc.add(new Chunk(Chunk.NEWLINE));

        // Agregar número de reporte
        Paragraph numeroBoleta = new Paragraph("N° " + String.format("%05d", numeroReporte), new Font(Font.FontFamily.TIMES_ROMAN, 14, Font.NORMAL, BaseColor.BLACK));
        numeroBoleta.setAlignment(Element.ALIGN_RIGHT);
        doc.add(numeroBoleta);
        doc.add(new Chunk(Chunk.NEWLINE));

        // Crear la tabla con las columnas correspondientes
        PdfPTable table = new PdfPTable(3); // 3 columnas: Cantidad, Descripción, Importe Total
        table.setWidthPercentage(100);

        // Agregar las celdas de encabezado
        String[] headers = {"Cantidad", "Descripción", "Importe Total"};
        for (String header : headers) {
            PdfPCell cell = new PdfPCell(new Phrase(header, new Font(Font.FontFamily.TIMES_ROMAN, 12, Font.BOLD, BaseColor.BLACK)));
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
            table.addCell(cell);
        }

        // Agregar las filas con los datos de la tabla
        double sumaTotal = 0;
        if (tablagos.getRowCount() > 0) {
            for (int i = 0; i < tablagos.getRowCount(); i++) {
                // Obtener la cantidad
                String cantidad = tablagos.getValueAt(i, 5).toString();

                // Obtener y combinar el Tipo, Medida, Modelo y Marca
                String tipo = tablagos.getValueAt(i, 1).toString();
                String medida = tablagos.getValueAt(i, 2).toString();
                String modelo = tablagos.getValueAt(i, 3).toString();
                String marca = tablagos.getValueAt(i, 4).toString();
                String descripcion = tipo + " " + medida + " " + modelo + " " + marca;

                // Calcular el importe total (Precio base x Cantidad)
                double precioBase = Double.parseDouble(tablagos.getValueAt(i, 6).toString());
                int cant = Integer.parseInt(cantidad);
                double importeTotal = precioBase * cant;
                sumaTotal += importeTotal;

                // Crear celdas con alineación centrada
                PdfPCell cantidadCell = new PdfPCell(new Phrase(cantidad));
                cantidadCell.setHorizontalAlignment(Element.ALIGN_CENTER);
                table.addCell(cantidadCell);

                PdfPCell descripcionCell = new PdfPCell(new Phrase(descripcion));
                descripcionCell.setHorizontalAlignment(Element.ALIGN_LEFT);
                table.addCell(descripcionCell);

                PdfPCell importeTotalCell = new PdfPCell(new Phrase(String.format("%.2f", importeTotal)));
                importeTotalCell.setHorizontalAlignment(Element.ALIGN_CENTER);
                table.addCell(importeTotalCell);
            }

            // Agregar la fila de total
            PdfPCell totalCell = new PdfPCell(new Phrase("Total:"));
            totalCell.setColspan(2); // Ocupa 2 columnas
            totalCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
            table.addCell(totalCell);

            PdfPCell sumaTotalCell = new PdfPCell(new Phrase(String.format("%.2f", sumaTotal)));
            sumaTotalCell.setHorizontalAlignment(Element.ALIGN_CENTER);
            table.addCell(sumaTotalCell);
        } else {
            // Si no hay datos, agregar una fila indicativa
            PdfPCell cell = new PdfPCell(new Phrase("No hay datos disponibles", new Font(Font.FontFamily.TIMES_ROMAN, 12, Font.ITALIC, BaseColor.RED)));
            cell.setColspan(3); // La fila indicativa debe ocupar todas las columnas
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            table.addCell(cell);
        }

        // Agregar la tabla al documento PDF
        doc.add(table);

        // Incrementar el número de reporte para el siguiente PDF
        numeroReporte++;

        // Cerrar el documento
        doc.close();
        archivo.close();

        System.out.println("PDF generado correctamente.");

    } catch (Exception e) {
        e.printStackTrace();
    } finally {
        if (doc != null) {
            doc.close();
        }
        if (archivo != null) {
            try {
                archivo.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}

// Método auxiliar para crear celdas de encabezado con estilo


}
